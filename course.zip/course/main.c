/**
 * @file main.c
 * @author Andrew Ho (hoa48@mcmaster.ca)
 * @brief info on main.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief info about the main function
 * 
 * creates new variable of struct type called MATH101.
 * it then gives the name of the course and course code to MATH101 by referencing the variables in the struct.
 * then it gives enrolls randomly generated students into the course.
 * then it prints the course contents.
 * it will then print the top student in the course.
 * it then prints out all of the current passing students along with the number of passing students.
 * 
 * @return int 
 */

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  //allocates space for MATH101 varaible
  strcpy(MATH101->name, "Basics of Mathematics");
  //assigns "Basics of Mathematics" to the name of MATH101
  strcpy(MATH101->code, "MATH 101");
  //assigns "MATH 101" to course code of MATH101

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  //enrolls randomly generated students into course using for loop
  
  print_course(MATH101);
  //prints all contents of the course

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
  //prints the top student in MATH101

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  //displays the total number of students passing and prints all the students who are passing
  
  return 0;
}