 /**
 * @file student.h
 * @author Andrew Ho (hoa48@mcmaster.ca)
 * @brief info on student.h
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
 /**
  * @brief info about the student struct
  * 
  * stores first name of student which can be up to 50 chars in first_name var.
  * stores last name of student which can be up to 50 chars in last)name var.
  * stores student id which is up to 11 characters in id var.
  * stores grades in *grades dynamic array.
  * stores number of grades in num_grades var.
  * 
  */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
  //variable declarations for student first name, last name, id, dynamic array for grades, and number of grades
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
