/**
 * @file course.h
 * @author Andrew Ho (hoa48@mcmaster.ca)
 * @brief info on course.h
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief info about the Course struct
 * 
 * stores course name which can be up to 100 characters in the name var.
 * stores the course code which is up to 10 characters in the code var.
 * also has a dynamic array which stores the information of all students enrolled in students var.
 * stores the total student count in the course in total_students var.
 * 
 */
 
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
  //variable declarations for course name, code, dynamic array for students, and total student count
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


