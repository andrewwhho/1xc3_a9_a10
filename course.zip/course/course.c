/**
 * @file course.c 
 * @author Andrew Ho (hoa48@mcmaster.ca)
 * @brief info on course.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022 
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief info about the enroll_student function
 * 
 * function will add 1 to the total_students variable in the course struct.
 * if the course was previously empty, it will allocate new space for the given size.
 * otherwise, it will reallocate new space for the updated student size.
 * the function will then assign the most recently enrolled student to the student pointer.
 * 
 * @param course pointer variable of Course struct.
 * @param student pointer variable of Student struct.
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++; //adds 1 to total students 
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); 
    //if this is the first student enrolled, then it will allocate 1 element the size of the dynamic array in the course struct
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
      //program will reallocate new space for the new total # of students otherwise
  }
  course->students[course->total_students - 1] = *student;
  //will assign the most recently enrolled student to the *student pointer
}

/**
 * @brief info about the print_course function
 * 
 * prints out header the course nsame, coures code, and total student count by referencing all the variables in the course struct.
 * it then prints out all the students in the course which is stored in the address of the students variable in the coruse struct.
 * 
 * @param course pointer variable of Course struct
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n"); //header for printing all course info 
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]); //for loop which prints all students currently enrolled
}

/**
 * @brief info about the top_student function 
 * 
 * function will return NULL if there is no one enrolled in the course.
 * function will iterate through all student averages and keep track of current highest.
 * it will replace the current highest average if a higher one is found.
 * function will then put the corresponding student with the highest grade into the student var.
 * function will then return the top student.
 * 
 * @param course pointer variable of Course struct
 * @return Student* returns student dynamic array 
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; 
  //returns NULL if there is no one enrolled in the course
 
  double student_average = 0;
  double max_average = average(&course->students[0]); //sets max average to first student
  Student *student = &course->students[0]; //sets current student to first student by referencing the students array in course struct
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]); //finds average of student in current iteration
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   //if current average is higher than previous, it will replace it
  }
  //algorithm which iterates through all student averages and keeps track of the highest

  return student; //returns highest student average
}

/**
 * @brief info about the *passing function
 * 
 * function will iterate through all the students in the course to determine if they are passing.
 * if the student in the current iteration is passing, it will add 1 to the counter.
 * the counter is then used to allocate space for an array of that size .
 * another for loop is then used to put each passing student into the array .
 * it will also assign count to the total_passing var.
 * function then returns the array full of all the passing students.
 * 
 * @param course pointer variable of Course struct
 * @param total_passing pointer of variable of int type
 * @return Student* returns dynamic array 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0; //count for students passing
  Student *passing = NULL; //dynamic array of students passing
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  //iterates through all students and adds to count if they are passing

  passing = calloc(count, sizeof(Student));
  //allocates enough space for the amount of students in array 

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  //iterates through all students and adds student to array if they are passing

  *total_passing = count;

  return passing;
}