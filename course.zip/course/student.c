/**
 * @file student.c
 * @author Andrew Ho (hoa48@mcmaster.ca)
 * @brief info on student.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief info about the add_grade function
 * 
 * function will add grade to the current students number of grades by adding 1 to num_grade var.
 * if it is the students only grade, it will allocate memory to store the grade.
 * otherwise it will reallocate more space to store the array of grades .
 * it will then assign the current student's grade to the grade var mentioned in the parameters.
 * 
 * @param student pointer varaible of Student struct
 * @param grade variable of double type
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++; //adds 1 to the students current number of grades
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //if this is the students only grade, it will allocate memory to store this grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //otherwise it will reallocate new memory to store the newly added grades in the array 
  student->grades[student->num_grades - 1] = grade;
  //assigns current student's grade the grade variable
}

/**
 * @brief info about the average function 
 * 
 * if the student has no grades, it will return 0 .
 * function then iterates through all the students grades adding it to a counter variable.
 * function then returns the total divded by number of grades to get average.
 * 
 * @param student pointer variable of Student struct
 * @return double returns variable of double type
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; //if student has no grades return 0 

  double total = 0; 
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  //adds all of the students current grades to total variable which is a counter
  return total / ((double) student->num_grades);
  //returns the average by dividing the total by number of grades
}

/**
 * @brief info about the print_student function 
 * 
 * function will start by printing the student first name, last name, and id by referencing those variables in the strudent struct.
 * function will then use a for loop to print all of the students current grades.
 * lastly, the function will then print out the average of all grades by calling the average function.
 * 
 * @param student pointer variable of Student struct
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  //prints students info by referencing the variables in the student struct
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  //prints all of the student's current grades using a for loop and referencing the variables in the student struct
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
  //prints student current average by calling the average function 
}

/**
 * @brief info about the generate_random_student function
 * 
 * function has two arrays full of student first and last names.
 * function will then allocate a variable to store the info of the new random student.
 * function picks a random first and last name to store in the new_student variable.
 * function will then randomly generate the new student's id.
 * it will then add random grades to the student's grades.
 * it will return the new random student.
 * 
 * @param grades variable of int type
 * @return Student* returns variable of student struct type
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 //arrays which contain all of the student first and last names

  Student *new_student = calloc(1, sizeof(Student));
  //allocates space to new_student which is Student struct type

  strcpy(new_student->first_name, first_names[rand() % 24]);
  //picks a random first name and copies it to first_name of new_student
  strcpy(new_student->last_name, last_names[rand() % 24]);
  //picks a random last name and copies it to last_name of new_student

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
  //generates a random id from digits and uses a for loop to store it in the id of new_student

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }
  //adds a grades to the student which are randomly generated 

  return new_student;
}